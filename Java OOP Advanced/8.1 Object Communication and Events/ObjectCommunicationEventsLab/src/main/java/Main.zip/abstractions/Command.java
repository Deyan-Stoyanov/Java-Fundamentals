package abstractions;

public interface Command {
    void execute();
}
