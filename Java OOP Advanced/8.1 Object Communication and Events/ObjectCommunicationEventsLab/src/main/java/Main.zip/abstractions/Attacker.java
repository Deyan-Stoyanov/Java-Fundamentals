package abstractions;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
