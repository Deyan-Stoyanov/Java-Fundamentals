package abstractions;

public interface Observer {
    void update(int i);
    String getId();
}
