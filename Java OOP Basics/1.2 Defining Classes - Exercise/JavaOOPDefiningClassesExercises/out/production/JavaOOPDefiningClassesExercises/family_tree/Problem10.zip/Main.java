package family_tree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Set<Person> people = new LinkedHashSet<>();
        Person person = new Person();
        String command = reader.readLine();
        if (command.matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}")) {
            person.setBirthDate(command);
        } else {
            person.setName(command);
        }
        people.add(person);
        while (!"End".equalsIgnoreCase(command = reader.readLine())) {
            if (command.contains("-")) {
                String[] input = command.split(" - ");
                if (input[0].matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}") && input[1].matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}")) {
                    if (people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[0])) && people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[1]))) {
                        for (Person parent : people) {
                            if (parent.getBirthDate().equalsIgnoreCase(input[0])) {
                                for (Person child : people) {
                                    if (child.getBirthDate().equalsIgnoreCase(input[1])) {
                                        parent.getChildren().add(child);
                                        child.getParents().add(parent);
                                    }
                                }
                            }
                        }
                    } else if (people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[0]))) {
                        Person child = new Person();
                        for (Person parent : people) {
                            if (parent.getBirthDate().equalsIgnoreCase(input[0])) {
                                child.setBirthDate(input[1]);
                                child.getParents().add(parent);
                                parent.getChildren().add(child);
                                break;
                            }
                        }
                        people.add(child);
                    } else if (people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[1]))) {
                        Person parent = new Person();
                        parent.setBirthDate(input[0]);
                        for (Person child : people) {
                            if (child.getBirthDate().equalsIgnoreCase(input[1])) {
                                parent.getChildren().add(child);
                                child.getParents().add(parent);
                                break;
                            }
                        }
                        people.add(parent);
                    } else {
                        Person parent = new Person();
                        parent.setBirthDate(input[0]);
                        Person child = new Person();
                        child.setBirthDate(input[1]);
                        parent.getChildren().add(child);
                        child.getParents().add(parent);
                        people.add(parent);
                        people.add(child);
                    }

                } else if (input[0].matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}")) {
                    if (people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[0])) && people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[1]))) {
                        for (Person parent : people) {
                            if (parent.getBirthDate().equalsIgnoreCase(input[0])) {
                                for (Person child : people) {
                                    if (child.getName().equalsIgnoreCase(input[1])) {
                                        parent.getChildren().add(child);
                                        child.getParents().add(parent);
                                    }
                                }
                            }
                        }
                    } else if (people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[0]))) {
                        Person child = new Person();
                        for (Person parent : people) {
                            if (parent.getBirthDate().equalsIgnoreCase(input[0])) {
                                child.setName(input[1]);
                                child.getParents().add(parent);
                                parent.getChildren().add(child);
                                break;
                            }
                        }
                        people.add(child);
                    } else if (people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[1]))) {
                        Person parent = new Person();
                        parent.setBirthDate(input[0]);
                        for (Person child : people) {
                            if (child.getName().equalsIgnoreCase(input[1])) {
                                parent.getChildren().add(child);
                                child.getParents().add(parent);
                                break;
                            }
                        }
                        people.add(parent);
                    } else {
                        Person parent = new Person();
                        parent.setBirthDate(input[0]);
                        Person child = new Person();
                        child.setName(input[1]);
                        parent.getChildren().add(child);
                        child.getParents().add(parent);
                        people.add(parent);
                        people.add(child);
                    }
                } else if (input[1].matches("[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}")) {
                    if (people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[0])) && people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[1]))) {
                        for (Person parent : people) {
                            if (parent.getName().equalsIgnoreCase(input[0])) {
                                for (Person child : people) {
                                    if (child.getBirthDate().equalsIgnoreCase(input[1])) {
                                        parent.getChildren().add(child);
                                        child.getParents().add(parent);
                                    }
                                }
                            }
                        }
                    } else if (people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[0]))) {
                        Person child = new Person();
                        for (Person parent : people) {
                            if (parent.getName().equalsIgnoreCase(input[0])) {
                                child.setBirthDate(input[1]);
                                child.getParents().add(parent);
                                parent.getChildren().add(child);
                                break;
                            }
                        }
                        people.add(child);

                    } else if (people.stream().anyMatch(x -> x.getBirthDate().equalsIgnoreCase(input[1]))) {
                        Person parent = new Person();
                        parent.setName(input[0]);
                        for (Person child : people) {
                            if (child.getBirthDate().equalsIgnoreCase(input[1])) {
                                parent.getChildren().add(child);
                                child.getParents().add(parent);
                                break;
                            }
                        }
                        people.add(parent);
                    } else {
                        Person parent = new Person();
                        parent.setName(input[0]);
                        Person child = new Person();
                        child.setBirthDate(input[1]);
                        parent.getChildren().add(child);
                        child.getParents().add(parent);
                        people.add(parent);
                        people.add(child);
                    }
                } else {
                    if (people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[0])) && people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[1]))) {
                        for (Person parent : people) {
                            if (parent.getName().equalsIgnoreCase(input[0])) {
                                for (Person child : people) {
                                    if (parent.getName().equalsIgnoreCase(input[1])) {
                                        parent.getChildren().add(child);
                                        child.getParents().add(parent);
                                    }
                                }
                            }
                        }
                    } else if (people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[0]))) {
                        Person child = new Person();
                        for (Person parent : people) {
                            if (parent.getName().equalsIgnoreCase(input[0])) {
                                child.setName(input[1]);
                                child.getParents().add(parent);
                                parent.getChildren().add(child);
                                break;
                            }
                        }
                        people.add(child);
                    } else if (people.stream().anyMatch(x -> x.getName().equalsIgnoreCase(input[1]))) {
                        Person parent = new Person();
                        parent.setName(input[0]);
                        for (Person child : people) {
                            if (child.getName().equalsIgnoreCase(input[1])) {
                                parent.getChildren().add(child);
                                child.getParents().add(parent);
                                break;
                            }
                        }
                        people.add(parent);
                    } else {
                        Person parent = new Person();
                        parent.setName(input[0]);
                        Person child = new Person();
                        child.setName(input[1]);
                        parent.getChildren().add(child);
                        child.getParents().add(parent);
                        people.add(parent);
                        people.add(child);
                    }
                }
            } else {
                String[] input = command.split(" ");
                boolean personAdded = false;
                for (Person person1 : people) {
                    if (person1.getBirthDate().equalsIgnoreCase(input[2]) || person1.getName().equalsIgnoreCase(input[0] + " " + input[1])) {
                        person1.setName(input[0] + " " + input[1]);
                        person1.setBirthDate(input[2]);
                        personAdded = true;
                    }
                }
                if (!personAdded) {
                    people.add(new Person(input[0] + " " + input[1], input[2]));
                }
            }
        }
        StringBuilder sb = new StringBuilder();

        people.stream()
                .filter(x -> x.getName().equals(person.getName()) && x.getBirthDate().equalsIgnoreCase(person.getBirthDate())).limit(1)
                .forEach(x -> {
                    sb.append(String.format("%s %s%n", x.getName(), x.getBirthDate())).append("Parents:").append(System.lineSeparator());
                    people.forEach(y -> {
                        if(y.getChildren().stream().anyMatch(c -> c.getName().equalsIgnoreCase(x.getName()) || c.getBirthDate().equalsIgnoreCase(x.getBirthDate()))){
                            sb.append(String.format("%s %s%n", y.getName(), y.getBirthDate()));
                        }
                    });
                    if (!x.getParents().isEmpty()) {
                        x.getParents().forEach(p -> sb.append(String.format("%s %s%n", p.getName(), p.getBirthDate())));
                    }
                    sb.append("Children:").append(System.lineSeparator());
                    if (!x.getChildren().isEmpty()) {
                        x.getChildren().forEach(c -> sb.append(String.format("%s %s%n", c.getName(), c.getBirthDate())));
                    }
                });
        System.out.println(sb.toString());
    }
}
