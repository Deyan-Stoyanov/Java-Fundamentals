package cat_lady;

public interface Cat {
    String getName();
    void setName(String name);
    double getStats();
    void setStats(double stats);
}
